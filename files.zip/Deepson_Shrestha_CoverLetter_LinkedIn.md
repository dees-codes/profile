# DEEPSON SHRESTHA

Senior Software Engineer | Distributed Systems, Security Infrastructure & Developer Platforms

Sterling, VA | (314) 537-0126 | Shrestha.Deepson@outlook.com | [linkedin.com/in/deepson-shrestha](https://www.linkedin.com/in/deepson-shrestha/)

---

Dear Hiring Team,

I'm applying for the Staff Software Engineer role on the Key Management and Cryptography team. The part of the job description that caught me was the framing: building developer-friendly libraries and APIs so other engineering teams can protect member data without becoming security experts themselves. That is the kind of work I've gravitated toward for five years.

At Mutual of Omaha I've built security infrastructure in a heavily regulated environment. I designed the authentication and authorization architecture for a platform serving over 100,000 users, spanning Okta SSO, LDAP-group entitlements, layered service APIs, and database stored procedures, protecting sensitive tax and identity data under federal electronic-consent requirements. I integrated HashiCorp Vault authentication for Redis services backing three production UIs, manage TLS certificate lifecycles for our event-driven services, and own vulnerability remediation through CodeQL, SonarQube, and exposed-secret scanning enforced as build gates.

I've also spent real effort on the leverage side of engineering. I built reusable API layers that downstream teams consume without rebuilding, co-wrote the enterprise API playbooks that became internal standards, and drove AI-assisted development adoption that leadership credited with a 30 percent coding-efficiency improvement across our business area. I use Claude daily for production code, not as a novelty but as a reviewed, tested part of the workflow.

I'll be direct about one thing: I've worked extensively with cryptographic systems as a consumer, managing keys, secrets, and certificates in production, but I have not implemented cryptographic primitives myself. That's a gap I'd close quickly and I'd rather say so upfront than let you discover it in an interview. What I bring is strong distributed systems fundamentals, deep security infrastructure experience, and a track record of shipping carefully in environments where mistakes carry real consequences.

I'd welcome the chance to talk about the team's roadmap and where I could contribute.

Best regards,

**Deepson Shrestha**
