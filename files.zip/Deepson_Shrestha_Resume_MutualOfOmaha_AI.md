# DEEPSON SHRESTHA

**AI Engineer | Full Stack, GenAI Applications & Cloud Architecture**

Sterling, VA | (314) 537-0126 | Shrestha.Deepson@outlook.com | [linkedin.com/in/deepson-shrestha](https://www.linkedin.com/in/deepson-shrestha/)

---

## PROFESSIONAL SUMMARY

Senior Software Engineer at Mutual of Omaha with five years deploying and supporting **full stack applications in an enterprise environment**, and several years integrating **AI and ML solutions**. Builds across backend, frontend, and database layers in **Python, TypeScript, Java, Vue.js, and React**, on **AWS** with **Bedrock, Lambda, S3, and CDK infrastructure as code**. Develops **GenAI applications end to end**: LLM integration, retrieval-augmented generation over enterprise documents, agentic orchestration, prompt and context engineering, structured schema-validated outputs, and evaluation harnesses measuring groundedness and citation accuracy before adoption. Works in a **regulated environment** where responsible AI, governance, and secure model deployment are requirements rather than aspirations. Drives adoption through mentorship, reusable templates, and enterprise-wide enablement.

---

## TECHNICAL SKILLS

**GenAI & LLM Application Development:** Amazon Bedrock (Anthropic Claude), Amazon SageMaker, LLM integration and orchestration patterns, agentic workflows and tool calling, Model Context Protocol integrations and custom automation, prompt engineering and context engineering (context window optimization, compaction), structured and schema-validated outputs, LangChain, LangGraph, HuggingFace, transformers fundamentals

**Retrieval & RAG:** RAG pipeline design over enterprise and regulatory document corpora, embeddings and vector stores (Pinecone, ElasticSearch), hybrid semantic and lexical retrieval, reranking (Cohere Rerank), retrieval optimization

**AI Evaluation & Responsible AI:** Evaluation pipelines for output and retrieval quality, A/B testing and systematic experimentation, training-data and prompt versioning, hallucination detection, groundedness and citation validation, human-in-the-loop review design, AI governance-compliant delivery in a regulated enterprise, secure model deployment practices

**AI Developer Tooling & Enablement:** GitHub Copilot, Windsurf, Claude Code; reusable templates and reference implementations, disciplined review of AI-generated code, driving adoption across engineering and non-engineering teams

**Full Stack Development:** Vue.js 3, Nuxt, React, TypeScript, JavaScript (ES6), single-page applications, micro-frontend composition (module federation), responsive and accessible UI, enterprise design systems; Spring Boot / Spring MVC, Node.js, Python services (Flask), REST and GraphQL (AWS AppSync) API design, microservices

**Languages:** Python, TypeScript, JavaScript (ES6), Java, Groovy, SQL, Bash

**AWS & Infrastructure as Code:** Bedrock, Lambda, S3, API Gateway, Step Functions, DynamoDB, RDS, Aurora PostgreSQL, Kinesis, Glue, CloudFront, CloudWatch, IAM, Secrets Manager, EC2, VPC; **AWS CDK** infrastructure as code, cost-optimized cloud-native architecture

**Data & Pipelines:** Snowflake, PostgreSQL, Microsoft SQL Server, IBM DB2 (mainframe, stored procedures), MongoDB, Redis; real-time streaming ingestion (Kinesis), ETL (Glue), multi-source data pipelines, feature and data preparation workflows, event-driven architecture (Apache Kafka, enterprise event bus)

**DevOps, CI/CD & Testing:** Jenkins (incl. Blue Ocean), GitHub Actions, Git/GitHub/Bitbucket, Docker, Kubernetes (Tanzu Kubernetes Grid, Helm, kubectl), automated quality gates (SonarQube, CodeQL, Xray), automated testing (Playwright, Cucumber/Gherkin BDD, Jest, Spock, MUnit, Grafana k6), observability and monitoring (CloudWatch, Grafana), on-call incident response

**Architecture & Methods:** Software engineering design patterns, enterprise application architecture, service-oriented and event-driven design, secure SDLC, DAST, Okta SSO, LDAP entitlements, RBAC, HashiCorp Vault, SAFe Agile, Scrum, technical design reviews, technical writing

---

## PROFESSIONAL EXPERIENCE

### Mutual of Omaha Insurance Company | Sterling, VA
*Distribution Operations Agile Release Train (producer compensation and producer management platforms)*

**Senior Software Engineer (Engineer II) / Engineer I** — Jul 2023 to Present

- **Drive GenAI adoption and enablement across the organization.** Built AI pair-programming workflows with disciplined context management for a **40 percent** personal throughput gain, trained business analysts to author their own automated tests with AI assistance, and presented AI engineering practices in four enterprise-wide sessions. Recognized by the VP of Corporate Operations for tooling credited with a **30 percent coding-efficiency improvement across the business area**.
- **Shape AI strategy at the business area level.** Active member of the enterprise **AI Community of Practice** and the **Distribution Operations AI Enablement group**, evaluating, piloting, and operationalizing AI-driven engineering improvements alongside architects and senior leadership.
- **Deploy and support full stack applications in an enterprise environment.** Lead front-end and integration development on a flagship modernization program replacing a legacy Java/JSP portal with a **TypeScript/Vue.js micro-frontend platform on AWS** backed by API-led services, delivering modules used nationwide by brokers of an insurer with $10B+ in annual revenue.
- **Build data and feature pipelines on AWS with infrastructure as code.** Designed a multi-source pipeline in **Python and TypeScript** ingesting into DynamoDB, moving through **Kinesis streaming and Glue ETL**, and delivering to **Snowflake** for a separate business division, with the stack defined via **AWS CDK**.
- **Own solutions end to end from prototype through production rollout.** Architected an electronic tax-document platform spanning Okta SSO, LDAP entitlements, layered service APIs, FileNet document retrieval, and DB2 stored procedures, meeting IRS electronic-consent regulations; carried it through secure design review and DAST to nationwide launch across **100,000+ users**, saving roughly **$60,000 per year**.
- **Apply systematic experimentation to technical decisions.** Ran a documented trade study across AWS Lambda, Glue, and Step Functions weighing scalability, cost, team skills, and platform direction, presented the recommendation, then implemented and migrated to it.
- **Ensure operational readiness and observability.** Maintain CI/CD pipelines with automated quality gates (SonarQube, CodeQL, Xray), monitor systems through CloudWatch and Grafana, and on the on-call rotation trace production failures across services, integrations, and streaming pipelines to root cause under hard deadlines.
- **Integrate with microservices and event-based architectures.** Built a vendor ingestion service (SFTP to S3 to Lambda to enterprise event bus) with strict schema validation, and delivered layered service APIs that downstream teams and external business partners consume without rebuilding.

**Application Developer** — Sep 2021 to Jul 2023

- Led a container platform migration of approximately **200 microservices** across three business units from Docker EE to **Kubernetes** (VMware Tanzu Kubernetes Grid), including Kafka event services, coordinating cutovers and environment promotion with five-plus platform and consumer teams.
- Integrated **HashiCorp Vault** authentication for Redis services backing three production UIs and multiple backend services, renewed Kafka TLS certificates, and modernized build and runtime stacks (Java 8 to 11, Gradle, Jenkins pipelines).
- Authored the enterprise **MuleSoft Skill Development Plan** used company-wide and co-wrote the enterprise Event and API playbooks adopted as internal engineering standards.

**Information Technology Intern** — May 2021 to Sep 2021

- Built a full-stack process-flow visualization application (Spring MVC, REST) with 100 percent automated test coverage; delivered 44 story points in three months, earning conversion to a full-time offer.

### Principal Financial Group | Des Moines, IA

**Software Engineering Intern** — May 2020 to Aug 2020

- Delivered web application features in the Individual Solutions department and collaborated with external vendors on the Retirement Income Calculator, raising team sprint velocity by 10 story points.
- Led a six-person team in a 105-intern Code Jam building a COVID-19 donor-matching web application (**Python, Flask, AWS**); placed 4th of 15 and presented to C-level executives.

---

## PERSONAL PROJECTS

### CompSync — AI-Native Compliance Platform

An AI-native BSA/AML transaction monitoring and compliance platform built end to end, piloted with a fintech.

- **GenAI application development on Amazon Bedrock (Claude):** automated narrative generation, regulation-cited rule creation, and **prompt-based rule tuning** that lets compliance staff adjust detection logic without engineering involvement, grounded by a **RAG pipeline for context retrieval** over federal regulatory guidance with **structured, schema-validated outputs**.
- **Responsible AI and evaluation:** automated evaluation for accuracy and traceability, **A/B testing** on detection logic, **training-data and prompt versioning** for reproducibility, and **human-in-the-loop review** so findings route through an analyst instead of acting autonomously.
- **Serverless architecture and model selection:** built on AWS (Lambda, API Gateway, Step Functions, Aurora PostgreSQL, S3) in **TypeScript** with least-privilege IAM; benchmarked **Amazon SageMaker** against Bedrock on cost, latency, and operational overhead before committing to an approach.

---

## LEADERSHIP & ENABLEMENT

- Featured in Mutual of Omaha's corporate careers blog, [**From Intern to Full-Stack Engineer: A Story of Growth**](https://www.mutualofomaha.com/careers/life-at-mutual/careers-blog/from-intern-to-full-stack-engineer-a-story-of-growth), a company-published profile of career progression and modernization work. Promoted through four levels on consecutive Outstanding performance ratings.
- Mentored four interns and engineers to full productivity (2022 to 2026), and served as technical liaison to an external five-student engineering team (University of Nebraska-Lincoln Raikes School), directing them through a full delivery lifecycle.
- Lead design and code reviews, author technical requirements documents and runbooks, and represented Mutual of Omaha at college career fairs and the CodePath program for emerging engineers.

---

## EDUCATION

**Master of Science in Information Studies** | Trine University, 2024–2025, GPA 3.90

**Bachelor of Science in Computer Science, cum laude** | Truman State University, 2018–2021, GPA 3.7

---

## CERTIFICATIONS

- **AWS Certified Cloud Practitioner**, 2021 | **MuleSoft Certified Integration Associate**, Salesforce, 2024 | **GitHub Foundations**, GitHub
- **Transformers in Practice**, DeepLearning.AI, 2026 | **Python Programming**, University of Michigan (Coursera), 2022 | Vendor-led **Snowflake** training
