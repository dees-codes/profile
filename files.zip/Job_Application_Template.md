# Job Application Template — Deepson Shrestha

> Contains sensitive personal data (SSN partial, DOB). Keep private.

---

## Personal

| Field | Value |
|---|---|
| Legal Name | Deepson Shrestha |
| Preferred Name | No |
| Address | 45582 Grand Central Sq, Sterling, VA 20166, United States of America |
| Email | Shrestha.Deepson@outlook.com |
| Phone | +1 314-537-0126 (Mobile) |
| Last 4 SSN | 0682 |
| DOB (MMDD) | 1204 |

---

## Work Experience

### Work Experience 1
- **Job Title:** Senior Software Engineer
- **Company:** Mutual of Omaha Insurance Company
- **Location:** Sterling, VA
- **Currently work here:** Yes
- **From:** 05/2021

**Role Description**

Progressed from Information Technology Intern to Application Developer to Engineer I to Senior Software Engineer (Engineer II) on consecutive Outstanding performance ratings. Lead front-end and integration development on a flagship enterprise modernization program, replacing a legacy Java/JSP portal with a TypeScript/Vue.js micro-frontend platform on AWS backed by API-led services. Partner with product, architecture, and business stakeholders to shape technical direction, carrying solutions from requirements through design review, security testing, and phased production rollout on a platform serving 100,000+ users. Previously led a container platform migration of approximately 200 microservices across three business units from Docker EE to Kubernetes, and authored the enterprise MuleSoft Skill Development Plan used company-wide. Automate team development and test processes, mentor engineers, and evaluate tools through documented technical analysis.

### Work Experience 2
- **Job Title:** Co-Founder, CEO & Founding Engineer
- **Company:** CompSync, Inc.
- **Location:** Sterling, VA
- **Currently work here:** Yes
- **From:** 02/2026

**Role Description**

Co-founded and lead an AI-native compliance SaaS platform for money services businesses and fintechs. Own the full stack end to end: architected the platform on AWS (Lambda, API Gateway, Step Functions, Aurora PostgreSQL) in TypeScript, with AI features on Amazon Bedrock grounded by a RAG retrieval pipeline. Signed the first paying design partner and advanced to the Techstars Anywhere interview round.

### Work Experience 3
- **Job Title:** Software Engineering Intern
- **Company:** Principal Financial Group
- **Location:** Des Moines, IA
- **Currently work here:** No
- **From:** 05/2020
- **To:** 08/2020

**Role Description**

Delivered web application features in the Individual Solutions department and collaborated with external vendors on the Retirement Income Calculator, raising team sprint velocity by 10 story points. Led a six-person team in a 105-intern Code Jam, placing 4th of 15 and presenting to C-level executives.

---

## Education

**Education 1**
- School: Trine University
- Degree: Masters
- Field of Study: Computer Information Systems *(note: diploma reads "Information Studies" — verify which to use)*
- GPA: 3.9

**Education 2**
- School: Truman State University
- Degree: Bachelors
- Field of Study: Computer Science
- GPA: 3.7

---

## Languages

All three: fluent = Yes, willing to use to serve customers = Yes

1. Nepali
2. English
3. Hindi

---

## Websites

1. https://www.mutualofomaha.com/careers/life-at-mutual/careers-blog/from-intern-to-full-stack-engineer-a-story-of-growth
2. https://compsync.us/
3. https://www.linkedin.com/in/deepson-shrestha/

---

## Standard Application Question Answers

| Question | Answer |
|---|---|
| Currently employed? | Yes |
| 18 years or older? | Yes |
| Legal right to work in the US? | Yes |
| Can provide I-9 work authorization documentation? | Yes |
| Will you now or in the future require visa sponsorship (e.g. H-1B)? | No |
| Willing to submit to drug screening? | Yes |
| Relatives employed at the company? | No |
| Reside with someone employed at the company? | No |
| Previously worked for this company? | No |
| How did you hear about us? | Other |
| Consent to AI/ML analysis of application | No |

---

## Voluntary Disclosures

| Field | Value |
|---|---|
| Gender | Male |
| Race/Ethnicity | Asian (United States of America) |
| Hispanic or Latino | No |

---

## Formatting Notes

- Some ATS forms reject these characters: `< > [ ] " { } \` — avoid quotation marks in descriptions
- If a form rejects the en dash (–) in date ranges, use a plain hyphen (-)
- The `&` in "Co-Founder, CEO & Founding Engineer" may need to be written as "and"
- Descriptions parse better as 2–3 short bullets when the field allows it

---

## Tailored Resumes Available

- Lowe's (Sr. Full Stack) — `Deepson_Shrestha_Resume_Lowes.pdf`
- SpaceX general (full stack / platform / applied AI) — `Deepson_Shrestha_Resume_SpaceX_General.pdf`
- SpaceX CI (Starship) — `Deepson_Shrestha_Resume_SpaceX.pdf`
- First Resonance (FDSE) — `Deepson_Shrestha_Resume_FirstResonance.pdf`
- Valthos (FDE) — `Deepson_Shrestha_Resume_Valthos.pdf`
- Aalo Atomics (AI Solutions) — `Deepson_Shrestha_Resume_Aalo.pdf`
- Ursa Major (Test Software) — `Deepson_Shrestha_Resume_UrsaMajor.pdf`
- DeepMind (FDE) — `Deepson_Shrestha_Resume_DeepMind.pdf`
- Skiffra (FDE) — `Deepson_Shrestha_Resume_Skiffra.pdf`
- Castelion (Ground Software) — `Deepson_Shrestha_Resume_Castelion.docx`
